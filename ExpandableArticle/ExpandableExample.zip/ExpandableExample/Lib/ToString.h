// Win2000 to_string replacement
// BobK6RWY


#pragma once


tstring to_tstring(int                Val);
tstring to_tstring(unsigned int       Val);
tstring to_tstring(long               Val);
tstring to_tstring(unsigned long      Val);
tstring to_tstring(long long          Val);
tstring to_tstring(unsigned long long Val);
tstring to_tstring(float              Val);
tstring to_tstring(double             Val);
tstring to_tstring(long double        Val);

